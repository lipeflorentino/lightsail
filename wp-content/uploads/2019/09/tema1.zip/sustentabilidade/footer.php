		<?php wp_footer(); ?>
		<div class="footer">
	  		<div class="container">
			    <div>
			      <a class="social-icon-link w-inline-block" href="#"><img src="http://uploads.webflow.com/560d79fc8d41e6275f31857f/560d79fc8d41e6275f3185b7_social-03.svg" width="20"></a><a class="social-icon-link w-inline-block" href="#"><img src="http://uploads.webflow.com/560d79fc8d41e6275f31857f/560d79fc8d41e6275f3185ce_social-18.svg" width="20"></a><a class="social-icon-link w-inline-block" href="#"><img src="http://uploads.webflow.com/560d79fc8d41e6275f31857f/560d79fc8d41e6275f3185aa_social-30.svg" width="20"></a>
			    </div>
	    		<div class="footer-text">© Copyright 2019 - Sustainability</div>
	  		</div>
		</div>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	  	<script type="text/javascript">
	      var ajaxurl = "<?php echo admin_url( 'admin-ajax.php' ); ?>"
		</script>
	</body>
</html>